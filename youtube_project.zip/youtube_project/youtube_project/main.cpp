#include"libs.h"

int main(void)
{
	glfwInit();
	return 0;
}